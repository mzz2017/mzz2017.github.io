#!/bin/bash
#
# /etc/rc2.d/S03xconfig
#

reconfigx(){
   echo "Reconfiguring xserver-xorg ... "
   dpkg-reconfigure -fnoninteractive --no-reload xserver-xorg
}


if [ -e /etc/X11/xconfig.log ] ;then
   lspci > /etc/X11/xconfig.tmp
   diff /etc/X11/xconfig.tmp  /etc/X11/xconfig.log > /etc/X11/different
   if [ -s /etc/X11/different ] ;then
       reconfigx
       # delete screen config
       lspci > /etc/X11/xconfig.log
   fi
else
   lspci > /etc/X11/xconfig.log
   reconfigx
fi


exit 0

